plugins {
    id("com.android.application") version "8.6.1" apply false
    // If you add other modules later (libraries), declare them here similarly.
    // id("com.android.library") version "8.6.1" apply false
}
