package com.example.healthylifestyle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class LogAdapter extends RecyclerView.Adapter<LogAdapter.VH> {

    public interface OnDelete { void delete(LogEntry entry); }

    private List<LogEntry> data;
    private final OnDelete onDelete;

    private final SimpleDateFormat fmt =
            new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

    // yyyy-MM-dd -> total sleep duration (ms) for that day
    private Map<String, Long> sleepMsByDay = new HashMap<>();

    // ===== Noise display helper (dBFS -> approx SPL) =====
    private static final float DEFAULT_NOISE_DB_OFFSET = 94f; // tune/calibrate if needed
    private static int displayNoiseDb(float dbfs) {
        int spl = Math.round(dbfs + DEFAULT_NOISE_DB_OFFSET);
        if (spl < 25)  spl = 25;   // clamp to a sensible range
        if (spl > 110) spl = 110;
        return spl;
    }
    // =====================================================

    // Called by HistoryActivity after it computes daily sleep totals
    public void setSleepDurationsMap(Map<String, Long> map) {
        this.sleepMsByDay = (map == null) ? new HashMap<>() : map;
        notifyDataSetChanged();
    }

    private static String dayKey(long epochMs) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(epochMs);
    }

    private static String fmtHm(Long ms) {
        if (ms == null || ms <= 0) return "--";
        long h = ms / (1000 * 60 * 60);
        long m = (ms / (1000 * 60)) % 60;
        return String.format(Locale.getDefault(), "%dh %02dm", h, m);
    }

    public LogAdapter(List<LogEntry> data, OnDelete onDelete) {
        this.data = data;
        this.onDelete = onDelete;
    }

    public void update(List<LogEntry> newData) {
        data = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_log, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        LogEntry e = data.get(pos);

        h.tvDate.setText(fmt.format(new Date(e.timestamp)));

        // Look up sleep for this day (based on the log's date key)
        String key = dayKey(e.timestamp);
        Long sleepMs = sleepMsByDay.get(key);
        String sleepStr = fmtHm(sleepMs);

        int spl = displayNoiseDb(e.dbfs); // use dbfs field from LogEntry

        String txt = "Steps: " + e.steps
                + " | Lux: " + Math.round(e.lux)
                + " | Noise: " + spl + " dB"
                + " | Walk: " + String.format(Locale.getDefault(), "%.2f km", e.km)
                + " | Sleep: " + sleepStr
                + " | Score: " + e.grade + " (" + e.score + ")";

        h.tvValues.setText(txt);

        h.btnDelete.setOnClickListener(v -> onDelete.delete(e));
    }

    @Override
    public int getItemCount() { return data == null ? 0 : data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvDate, tvValues;
        Button btnDelete;
        VH(@NonNull View v) {
            super(v);
            tvDate = v.findViewById(R.id.tvDate);
            tvValues = v.findViewById(R.id.tvValues);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}
