package com.example.healthylifestyle;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(
        entities = { LogEntry.class, SleepSession.class }, // add any other @Entity here
        version = 4,                                       // ⬅ bump when entities change
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract LogDao logDao();
    public abstract SleepDao sleepDao();

    // Optional: example migration kept for reference (2 -> 3 added sleep_sessions)
    private static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL(
                    "CREATE TABLE IF NOT EXISTS sleep_sessions (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                            "startTime INTEGER NOT NULL, " +
                            "endTime INTEGER)"
            );
        }
    };

    public static AppDatabase getInstance(Context ctx) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    ctx.getApplicationContext(),
                                    AppDatabase.class,
                                    "health_db")
                            // While developing, wipe+recreate on schema changes to avoid crashes.
                            .fallbackToDestructiveMigration()
                            // You can keep specific migrations too (not required with fallback):
                            .addMigrations(MIGRATION_2_3)
                            // OK for a class project; move DB work off main thread later.
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
