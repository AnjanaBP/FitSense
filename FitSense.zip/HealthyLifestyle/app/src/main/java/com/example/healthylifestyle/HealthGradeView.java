package com.example.healthylifestyle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import com.google.android.material.color.MaterialColors;

public class HealthGradeView extends View {

    private String grade = "--";
    private int score = 0;

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF oval = new RectF();

    public HealthGradeView(Context c) { super(c); init(); }
    public HealthGradeView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        // Device-scaled sizes
        float dp = getResources().getDisplayMetrics().density;
        float sp = getResources().getDisplayMetrics().scaledDensity;

        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(24f * dp);
        ring.setStrokeCap(Paint.Cap.ROUND); // nicer arc ends

        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(48f * sp);         // was 96f (very large); adjust as you like
        // Set the text color to theme primary (purple) for visibility on black
        int primary = MaterialColors.getColor(this,
                com.google.android.material.R.attr.colorPrimary);
        text.setColor(primary);
    }

    /** Set grade letter (A–F) and score 0..100, then redraw. */
    public void setGradeAndScore(String g, int s) {
        grade = (g == null || g.trim().isEmpty()) ? "--" : g.trim();
        score = Math.max(0, Math.min(100, s));
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float inset = 24f * getResources().getDisplayMetrics().density;
        oval.set(inset, inset, w - inset, h - inset);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);

        // Ring color depends on grade letter
        ring.setColor(colorForGrade(grade));

        // Map 0..100 to 0..300 degrees sweep, starting at 120° (same as your original)
        float sweep = (score / 100f) * 300f;
        c.drawArc(oval, 120f, sweep, false, ring);

        // Center text precisely using font metrics
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        Paint.FontMetrics fm = text.getFontMetrics();
        float textBaseline = cy - (fm.ascent + fm.descent) / 2f;

        c.drawText(grade, cx, textBaseline, text);
    }

    /** Map letter grade -> ring color. */
    private int colorForGrade(String g) {
        // Material-ish palette
        final int A_GREEN     = 0xFF2E7D32; // stronger green
        final int B_GREEN     = 0xFF388E3C;
        final int C_AMBER     = 0xFFF9A825;
        final int D_ORANGE    = 0xFFFB8C00;
        final int E_RED       = 0xFFE53935;
        final int F_DARK_RED  = 0xFFB71C1C;
        final int NEUTRAL_GRY = 0xFF9E9E9E;

        if (g == null) return NEUTRAL_GRY;
        switch (g) {
            case "A": return A_GREEN;
            case "B": return B_GREEN;
            case "C": return C_AMBER;
            case "D": return D_ORANGE;
            case "E": return E_RED;
            case "F": return F_DARK_RED;
            default:  return NEUTRAL_GRY;
        }
    }
}
