package com.example.healthylifestyle;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Looper;

import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.*;

public class WalkTracker {
    private final FusedLocationProviderClient client;
    private Location last;
    private float meters = 0;

    public WalkTracker(Context ctx){ client = LocationServices.getFusedLocationProviderClient(ctx); }

    private final LocationCallback callback = new LocationCallback(){
        @Override public void onLocationResult(LocationResult result) {
            for (Location loc: result.getLocations()){
                if (last != null) meters += last.distanceTo(loc);
                last = loc;
            }
        }
    };

    @SuppressLint("MissingPermission") // safe because we guard below
    public void start(Context ctx){
        LocationRequest req = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 5000
        ).setMinUpdateDistanceMeters(5).build();

        // ✅ Guard: only request updates if permission is granted
        boolean fine = ActivityCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        boolean coarse = ActivityCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;

        if (!fine && !coarse) {
            // no permission → do nothing (caller should request it first)
            return;
        }

        client.requestLocationUpdates(req, callback, Looper.getMainLooper());
    }

    public void stop(){ client.removeLocationUpdates(callback); }
    public float getKm(){ return meters / 1000f; }
    public void reset(){ meters = 0; last = null; }
}
