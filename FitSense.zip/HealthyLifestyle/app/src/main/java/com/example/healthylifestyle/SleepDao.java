package com.example.healthylifestyle;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface SleepDao {
    @Insert
    long insert(SleepSession session);

    @Query("SELECT * FROM sleep_sessions WHERE endTime IS NULL LIMIT 1")
    SleepSession getOpenSession();

    @Query("UPDATE sleep_sessions SET endTime = :endMillis WHERE id = :id")
    void closeSession(int id, long endMillis);

    @Query("SELECT * FROM sleep_sessions ORDER BY startTime DESC")
    List<SleepSession> getAll();

    @Query("SELECT * FROM sleep_sessions WHERE startTime >= :fromEpoch ORDER BY startTime DESC")
    List<SleepSession> getSince(long fromEpoch);

    @Query("DELETE FROM sleep_sessions WHERE id = :id")
    void deleteById(int id);

    // SleepDao.java
    @Query("SELECT * FROM sleep_sessions WHERE endTime IS NOT NULL ORDER BY endTime DESC LIMIT 1")
    SleepSession getLastCompleted();

    @Query("SELECT SUM(endTime - startTime) FROM sleep_sessions WHERE endTime IS NOT NULL AND startTime >= :fromEpoch")
    Long getTotalDurationSince(long fromEpoch);

    // SleepDao.java
    @Query("SELECT * FROM sleep_sessions WHERE endTime IS NOT NULL")
    List<SleepSession> getAllCompleted();


}
