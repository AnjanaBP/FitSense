package com.example.healthylifestyle;
import java.text.NumberFormat;
import java.util.Locale;
import android.view.View;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class MainActivity extends AppCompatActivity {
    // Metric card views
    private TextView tvStepsValue, tvStepsNote, tvSleepValueBig, tvNoiseValue, tvWalkValue;
    private ProgressBar pbSleep;
    public static final String EXTRA_STEPS = "extra_steps";
    public static final String EXTRA_LUX   = "extra_lux";
    public static final String EXTRA_DB    = "extra_db";   // raw dBFS
    public static final String EXTRA_KM    = "extra_km";
    public static final String EXTRA_SCORE = "extra_score";
    public static final String EXTRA_GRADE = "extra_grade";
    public static final String EXTRA_SLEEP_MIN = "extra_sleep_min";

    // ----- Database -----
    private AppDatabase db;
    private LogDao logDao;
    private SleepDao sleepDao;

    // ----- UI -----
    private HealthGradeView gradeView;
    private TextView scoreText, summaryText;

    // Sleep UI
    private Button btnStartSleep, btnStopSleep;
    private TextView tvSleepTimer, tvSleepSummary;

    private Button btnCompute, btnDetails, btnMeasureNoise, btnSampleLight, btnWalkToggle, btnSettings;

    // ----- Sensors/helpers -----
    private StepTracker stepTracker;
    private LightSampler lightSampler;
    private NoiseMeter noiseMeter;
    private WalkTracker walkTracker;

    // ----- State -----
    private float lastAvgLux = 0f;
    private float lastAvgDb = 0f;
    private boolean walking = false;

    private int lastComputedScore = 0;
    private String lastComputedGrade = "--";

    private int stepGoal = 8000;
    private float walkGoalKm = 3.0f;

    private static final int REQ_PERMS = 101;

    // ---------- Sleep helpers ----------
    private static String fmtHm(long ms) {
        if (ms == 0) return "--";
        long h = ms / (1000 * 60 * 60);
        long m = (ms / (1000 * 60)) % 60;
        return String.format(Locale.getDefault(), "%dh %02dm", h, m);
    }

    // ≈ device calibration: dB SPL when the mic math reports 0 dBFS.
// 94 dB is a common reference level. You can tune this later.
    private static final float NOISE_DB_OFFSET = 94f;

//    /** Convert mic dBFS (usually negative) to a friendly dB SPL number. */
//    private int displayNoiseDb(float dbfs) {
//        // SPL ≈ dBFS + offset; clamp sensibly
//        int spl = Math.round(dbfs + NOISE_DB_OFFSET);
//        if (spl < 0) spl = 0;
//        if (spl > 120) spl = 120;
//        return spl;
//    }
// Load a calibrated offset if you saved one; otherwise use default.
private float noiseOffset = NOISE_DB_OFFSET;

    // Call once in onCreate()
    private void initNoiseOffset() {
        noiseOffset = getSharedPreferences("prefs", MODE_PRIVATE)
                .getFloat("noise_db_offset", NOISE_DB_OFFSET);
    }

    /** Convert mic dBFS (negative) to display SPL. This is approximate, offset-based. */
    private int displayNoiseDb(float dbfs) {
        // Guard: some mic code returns very small/NaN when silent
        if (Float.isNaN(dbfs) || dbfs < -160f) return 0;

        // SPL ≈ dBFS + offset
        int spl = Math.round(dbfs + noiseOffset);

        // Clamp to a sensible human range
        if (spl < 25)  spl = 25;   // ~very quiet room
        if (spl > 110) spl = 110;  // ~concert level
        return spl;
    }

    /** Total sleep minutes for the current calendar day (00:00–24:00), including an open session. */
    private int getSleepMinutesToday() {
        long now = System.currentTimeMillis();

        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTimeInMillis(now);
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        long startOfDay = cal.getTimeInMillis();

        // Sum completed sessions since start of day
        Long totalMs = sleepDao.getTotalDurationSince(startOfDay);
        long sum = (totalMs == null) ? 0L : totalMs;

        // Include open session (if any) up to "now"
        SleepSession open = sleepDao.getOpenSession();
        if (open != null) {
            long st = Math.max(open.startTime, startOfDay);
            if (now > st) sum += (now - st);
        }

        return (int) Math.max(0, Math.round(sum / 60000.0)); // minutes
    }

    private void updateSleepSummary() {
        // last completed session
        SleepSession last = sleepDao.getLastCompleted();
        String lastTxt = (last == null || last.endTime == null) ? "--" : fmtHm(last.endTime - last.startTime);

        // total last 7 days
        long sevenDaysAgo = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000;
        Long totalMs = sleepDao.getTotalDurationSince(sevenDaysAgo);
        String weekTxt = (totalMs == null) ? "--" : fmtHm(totalMs);

        if (tvSleepSummary != null) {
            tvSleepSummary.setText("Last sleep: " + lastTxt + " | Last 7 days: " + weekTxt);
        }
    }

    // Live ticker while a session is running
    private final Handler sleepHandler = new Handler(Looper.getMainLooper());
    private final Runnable sleepTicker = new Runnable() {
        @Override public void run() {
            SleepSession open = sleepDao.getOpenSession();
            if (open != null && tvSleepTimer != null) {
                long ms = System.currentTimeMillis() - open.startTime;
                long h = ms / (1000 * 60 * 60);
                long m = (ms / (1000 * 60)) % 60;
                long s = (ms / 1000) % 60;
                tvSleepTimer.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s));
                sleepHandler.postDelayed(this, 1000);
            } else if (tvSleepTimer != null) {
                tvSleepTimer.setText("--:--:--");
            }
        }
    };

    // ---------- Settings result ----------
    private final ActivityResultLauncher<Intent> settingsLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();
                    stepGoal = data.getIntExtra("stepGoal", stepGoal);
                    walkGoalKm = data.getFloatExtra("walkGoalKm", walkGoalKm);
                    Toast.makeText(this, "Goals updated", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvStepsValue    = findViewById(R.id.tvStepsValue);
        tvStepsNote     = findViewById(R.id.tvStepsNote);
        tvSleepValueBig = findViewById(R.id.tvSleepValueBig);
        pbSleep         = findViewById(R.id.pbSleep);
        tvNoiseValue    = findViewById(R.id.tvNoiseValue);
        tvWalkValue     = findViewById(R.id.tvWalkValue);

        // ----- DB -----
        db = AppDatabase.getInstance(this);
        logDao = db.logDao();
        sleepDao = db.sleepDao();

        // ----- Find views -----
        gradeView       = findViewById(R.id.gradeView);
        scoreText       = findViewById(R.id.scoreText);
        summaryText     = findViewById(R.id.summaryText);
        btnCompute      = findViewById(R.id.btnCompute);
        btnDetails      = findViewById(R.id.btnDetails);
        btnMeasureNoise = findViewById(R.id.btnMeasureNoise);
        btnSampleLight  = findViewById(R.id.btnSampleLight);
        btnWalkToggle   = findViewById(R.id.btnWalkToggle);
        btnSettings     = findViewById(R.id.btnSettings);
        Button btnSaveToday   = findViewById(R.id.btnSaveToday);
        Button btnOpenHistory = findViewById(R.id.btnOpenHistory);
        // --- Metric card views ---



        // Sleep views
        btnStartSleep   = findViewById(R.id.btnStartSleep);
        btnStopSleep    = findViewById(R.id.btnStopSleep);
        tvSleepTimer    = findViewById(R.id.tvSleepTimer);
        tvSleepSummary  = findViewById(R.id.tvSleepSummary);

        // ----- Helpers -----
        stepTracker  = new StepTracker(this);
        lightSampler = new LightSampler(this);
        noiseMeter   = new NoiseMeter();
        walkTracker  = new WalkTracker(this);

        ensureRuntimePerms();

        // ----- Settings -----
        btnSettings.setOnClickListener(v -> {
            Intent i = new Intent(this, SettingsActivity.class);
            i.putExtra("stepGoal", stepGoal);
            i.putExtra("walkGoalKm", walkGoalKm);
            settingsLauncher.launch(i);
        });

        // ----- Compute score -----
        btnCompute.setOnClickListener(v -> {
            int steps = stepTracker.getTodaySteps();
            float km  = walkTracker.getKm();

            int sleepMinToday = getSleepMinutesToday();
            int sSteps = ScoreCalculator.steps(steps, stepGoal);
            int sSleep = ScoreCalculator.sleepCombined(sleepMinToday, lastAvgLux); // duration + lux
            int sNoise = ScoreCalculator.noise(lastAvgDb);
            int sWalk  = ScoreCalculator.walk(km, walkGoalKm);

            int total  = ScoreCalculator.total(sSteps, sSleep, sNoise, sWalk);
            String grade = ScoreCalculator.grade(total);

            lastComputedScore = total;
            lastComputedGrade = grade;

            gradeView.setGradeAndScore(grade, total);
            scoreText.setText("Health Score: " + grade + " (" + total + ")");
            updateMetricCards(steps, sleepMinToday, (int) lastAvgLux, Math.round(lastAvgDb), km);
            updateStepsSubtitle(steps);
            // keep old one-line summary if you want it (even if hidden)
            updateSummaryUI(steps, sleepMinToday, lastAvgLux, lastAvgDb, km);
        });

        // ----- Details -----
        btnDetails.setOnClickListener(v -> {
            int steps = stepTracker.getTodaySteps();
            float lux  = lastAvgLux;
            float dbfs = lastAvgDb;        // keep raw negative dBFS; convert in Details
            float km   = walkTracker.getKm();
            int sleepMin = getSleepMinutesToday();

            int sSteps = ScoreCalculator.steps(steps, stepGoal);
            int sSleep = ScoreCalculator.sleepCombined(sleepMin, lux);
            int sNoise = ScoreCalculator.noise(dbfs);
            int sWalk  = ScoreCalculator.walk(km, walkGoalKm);
            int total  = ScoreCalculator.total(sSteps, sSleep, sNoise, sWalk);
            String grade = ScoreCalculator.grade(total);

            Intent d = new Intent(this, DetailsActivity.class);
            d.putExtra(EXTRA_STEPS, steps);
            d.putExtra(EXTRA_LUX, lux);
            d.putExtra(EXTRA_DB, dbfs);
            d.putExtra(EXTRA_KM, km);
            d.putExtra(EXTRA_SLEEP_MIN, sleepMin);
            d.putExtra(EXTRA_SCORE, total);
            d.putExtra(EXTRA_GRADE, grade);
            startActivity(d);
        });


        // ----- Save today's log -----
        btnSaveToday.setOnClickListener(v -> {
            int steps = stepTracker.getTodaySteps();
            float lux  = lastAvgLux;
            float dbv  = lastAvgDb;
            float km   = walkTracker.getKm();

            int sleepMinToday = getSleepMinutesToday();
            int sSteps = ScoreCalculator.steps(steps, stepGoal);
            int sSleep = ScoreCalculator.sleepCombined(sleepMinToday, lux);
            int sNoise = ScoreCalculator.noise(dbv);
            int sWalk  = ScoreCalculator.walk(km, walkGoalKm);
            int total  = ScoreCalculator.total(sSteps, sSleep, sNoise, sWalk);
            String grade = ScoreCalculator.grade(total);

            long now = System.currentTimeMillis();
            LogEntry entry = new LogEntry(now, steps, lux, lastAvgDb /* dbfs */, km, total, grade);
            logDao.insert(entry);


            gradeView.setGradeAndScore(grade, total);
            scoreText.setText("Health Score: " + grade + " (" + total + ")");
            updateStepsSubtitle(steps);
            // NEW: fill the mini-cards
            updateMetricCards(steps, sleepMinToday, (int) lux, Math.round(dbv), km);

            updateSummaryUI(steps, sleepMinToday, lux, dbv, km);
            Toast.makeText(this, "Saved today’s log", Toast.LENGTH_SHORT).show();
        });


        // ----- Open history -----
        btnOpenHistory.setOnClickListener(v ->
                startActivity(new Intent(this, HistoryActivity.class)));

        // ----- Noise (10s) -----
        btnMeasureNoise.setOnClickListener(v -> {
            if (!has(Manifest.permission.RECORD_AUDIO)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_PERMS);
                return;
            }
            Toast.makeText(this, "Measuring noise for 10s…", Toast.LENGTH_SHORT).show();
            noiseMeter.start();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                noiseMeter.stop();
                lastAvgDb = noiseMeter.getAvgDb();
                Toast.makeText(this,
                        "Avg noise: " + displayNoiseDb(lastAvgDb) + " dB",
                        Toast.LENGTH_SHORT).show();            }, 10_000);
        });

        // ----- Light (30s) -----
        btnSampleLight.setOnClickListener(v -> {
            if (!lightSampler.isAvailable()) {
                Toast.makeText(this, "Light sensor not available", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Sampling light for 30s…", Toast.LENGTH_SHORT).show();
            lightSampler.start();
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                lightSampler.stop();
                lastAvgLux = lightSampler.getAverageLux();
                Toast.makeText(this, "Avg light: " + String.format(Locale.US, "%.0f lux", lastAvgLux), Toast.LENGTH_SHORT).show();
            }, 30_000);
        });

        // ----- Walk toggle -----
        btnWalkToggle.setOnClickListener(v -> {
            if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_PERMS);
                return;
            }
            if (!walking) {
                walkTracker.reset();
                walkTracker.start(this);
                walking = true;
                btnWalkToggle.setText("Stop Walk");
                Toast.makeText(this, "Walking tracking started", Toast.LENGTH_SHORT).show();
            } else {
                walkTracker.stop();
                walking = false;
                btnWalkToggle.setText("Start Walk");
                Toast.makeText(this, "Walk distance: " +
                        String.format(Locale.US, "%.2f km", walkTracker.getKm()), Toast.LENGTH_SHORT).show();
            }
        });

        // ----- Sleep controls -----
        refreshSleepButtons();
        startSleepTickerIfNeeded();
        updateSleepSummary();  // show last/weekly as soon as screen opens

        btnStartSleep.setOnClickListener(v -> {
            if (sleepDao.getOpenSession() != null) {
                Toast.makeText(this, "Sleep already running.", Toast.LENGTH_SHORT).show();
                return;
            }
            sleepDao.insert(new SleepSession(System.currentTimeMillis(), null));
            Toast.makeText(this, "Sleep started.", Toast.LENGTH_SHORT).show();
            refreshSleepButtons();
            startSleepTickerIfNeeded();
            // don't update summary yet (no end time)
        });

        btnStopSleep.setOnClickListener(v -> {
            SleepSession open = sleepDao.getOpenSession();
            if (open == null) {
                Toast.makeText(this, "No sleep session running.", Toast.LENGTH_SHORT).show();
                return;
            }
            long end = System.currentTimeMillis();
            sleepDao.closeSession(open.id, end);

            long durMs = end - open.startTime;
            long hrs = durMs / (1000 * 60 * 60);
            long mins = (durMs / (1000 * 60)) % 60;

            Toast.makeText(this, "Slept for " + hrs + "h " + mins + "m", Toast.LENGTH_LONG).show();
            refreshSleepButtons();
            startSleepTickerIfNeeded();
            updateSleepSummary();  // now we have a completed session
        });
    }


    private String stepProgressMessage(int steps, int goal) {
        if (goal <= 0) return "No goal set yet";   // safety

        NumberFormat fmt = NumberFormat.getIntegerInstance(Locale.getDefault());
        int remaining = Math.max(0, goal - steps);
        float p = steps / (float) goal;  // 0..1+

        if (p < 0.10f) return "Let’s get started — " + fmt.format(remaining) + " to go";
        if (p < 0.25f) return "Good start! " + fmt.format(remaining) + " steps left";
        if (p < 0.50f) return "Making progress — " + fmt.format(remaining) + " to go";
        if (p < 0.80f) return "Nice! You're halfway to your step goal 🎯";
        if (p < 1.00f) return "Almost there — " + fmt.format(remaining) + " left!";
        if (p < 1.20f) return "Goal reached! 🎉";
        return "Crushing it — keep it up!";
    }


    private void updateStepsSubtitle(int steps) {
        if (tvStepsNote == null) return;
        tvStepsNote.setText(stepProgressMessage(steps, stepGoal));
        tvStepsNote.setVisibility(View.VISIBLE);
    }


    private void updateMetricCards(int steps, int sleepMinutes, int lux, int noiseDb, double walkKm) {
        NumberFormat intFmt = NumberFormat.getIntegerInstance();
        NumberFormat kmFmt  = NumberFormat.getNumberInstance();
        kmFmt.setMinimumFractionDigits(2);
        kmFmt.setMaximumFractionDigits(2);

        // Steps
        if (tvStepsValue != null) tvStepsValue.setText(intFmt.format(steps));
        if (tvStepsNote != null) {
            tvStepsNote.setText(steps >= 10000
                    ? "Awesome! You hit your step goal 🎉"
                    : "Nice! You're halfway to your step goal 🎉");
        }

        // Sleep
        if (tvSleepValueBig != null) {
            int h = sleepMinutes / 60, m = sleepMinutes % 60;
            tvSleepValueBig.setText(h + "h " + m + "m");
        }
        if (pbSleep != null) {
            int targetMin = 8 * 60; // change if you have a user goal
            int pct = Math.max(0, Math.min(100, Math.round((sleepMinutes * 100f) / targetMin)));
            pbSleep.setProgress(pct);
        }

        // Noise
        if (tvNoiseValue != null) {
            int spl = displayNoiseDb(noiseDb);  // noiseDb is your dbfs value (can be negative)
            tvNoiseValue.setText(spl + " dB");
        }
        // Walk
        if (tvWalkValue != null) tvWalkValue.setText(kmFmt.format(walkKm) + " km");
    }

    @Override protected void onStart() {
        super.onStart();
        stepTracker.start();
        startSleepTickerIfNeeded();
        updateSleepSummary();
    }

    @Override protected void onStop() {
        super.onStop();
        stepTracker.stop();
        if (walking) { walkTracker.stop(); walking = false; btnWalkToggle.setText("Start Walk"); }
        lightSampler.stop();
        noiseMeter.stop();
        sleepHandler.removeCallbacks(sleepTicker);
    }

    // ----- helpers -----
    private boolean has(String p) {
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureRuntimePerms() {
        java.util.ArrayList<String> need = new java.util.ArrayList<>();
        if (!has(Manifest.permission.ACTIVITY_RECOGNITION)) need.add(Manifest.permission.ACTIVITY_RECOGNITION);
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
        if (!need.isEmpty()) ActivityCompat.requestPermissions(this, need.toArray(new String[0]), REQ_PERMS);
    }

    private void refreshSleepButtons() {
        boolean running = (sleepDao.getOpenSession() != null);
        btnStartSleep.setEnabled(!running);
        btnStopSleep.setEnabled(running);
    }

    private void startSleepTickerIfNeeded() {
        sleepHandler.removeCallbacks(sleepTicker);
        if (sleepDao.getOpenSession() != null) {
            sleepHandler.post(sleepTicker);
        } else if (tvSleepTimer != null) {
            tvSleepTimer.setText("--:--:--");
        }
    }

    private void updateSummaryUI(int steps, int sleepMin, float lux, float db, float km) {
        summaryText.setText(
                "Steps: " + steps +
                        " | Sleep: " + (sleepMin / 60) + "h " + (sleepMin % 60) + "m" +
                        " (" + String.format(Locale.US, "%.0f", lux) + " lux)" +
                        " | Noise: " + displayNoiseDb(db) + " dB" +
                        " | Walk: " + String.format(Locale.US, "%.2f", km) + " km"
        );
    }
}
