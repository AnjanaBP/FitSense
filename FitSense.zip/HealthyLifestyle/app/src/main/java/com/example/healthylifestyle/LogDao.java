package com.example.healthylifestyle;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LogDao {

    @Insert
    void insert(LogEntry entry);

    // All logs, newest first
    @Query("SELECT * FROM daily_logs ORDER BY timestamp DESC")
    List<LogEntry> getAllDesc();

    // Last (most recent) log
    @Query("SELECT * FROM daily_logs ORDER BY timestamp DESC LIMIT 1")
    LogEntry getLast();

    // Logs since a given epoch millis
    @Query("SELECT * FROM daily_logs WHERE timestamp >= :fromEpoch ORDER BY timestamp DESC")
    List<LogEntry> getSince(long fromEpoch);

    // Delete by primary key
    @Query("DELETE FROM daily_logs WHERE id = :id")
    void deleteById(long id);
}
