package com.example.healthylifestyle;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class StepTracker {
    private final SensorManager sm;
    private final Sensor stepCounter;
    private float base = -1;
    private int todaySteps = 0;

    public StepTracker(Context ctx){
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        stepCounter = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
    }

    private final SensorEventListener listener = new SensorEventListener() {
        @Override public void onSensorChanged(SensorEvent e) {
            float total = e.values[0];
            if (base < 0) base = total;
            todaySteps = Math.max(0, Math.round(total - base));
        }
        @Override public void onAccuracyChanged(Sensor sensor, int acc) {}
    };

    public void start(){ if (stepCounter != null) sm.registerListener(listener, stepCounter, SensorManager.SENSOR_DELAY_NORMAL); }
    public void stop(){ sm.unregisterListener(listener); }
    public int getTodaySteps(){ return todaySteps; }
    public boolean isAvailable(){ return stepCounter != null; }
}
