package com.example.healthylifestyle;

public class ScoreCalculator {

    // ---- Weights (total = 1.0f) ----
    private static final float W_STEPS = 0.30f;
    private static final float W_SLEEP = 0.25f; // sleepCombined goes here
    private static final float W_NOISE = 0.20f;
    private static final float W_WALK  = 0.25f;

    // ---- Utility ----
    private static int clamp0to100(int v) {
        return Math.max(0, Math.min(100, v));
    }

    // ---- Steps (linear to goal, capped at 100) ----
    public static int steps(int steps, int goal) {
        float g = Math.max(1, goal); // avoid /0
        int score = Math.round(Math.min(1f, steps / g) * 100f);
        return clamp0to100(score);
    }

    // ---- Walk distance (linear to goal, capped at 100) ----
    public static int walk(float km, float goal) {
        float g = Math.max(0.5f, goal); // keep denominator sensible
        int score = Math.round(Math.min(1f, km / g) * 100f);
        return clamp0to100(score);
    }

    // ---- Noise (bucketed) ----
    // <45 dB: 100, <60: 80, <70: 60, else: 40
    public static int noise(float db) {
        if (db < 45f) return 100;
        if (db < 60f) return 80;
        if (db < 70f) return 60;
        return 40;
    }

    // ---- Sleep (lux → darkness score; bucketed) ----
    // ≤20:100, ≤50:85, ≤100:65, else:40
    public static int sleepLux(float avgLux) {
        if (avgLux <= 20f)  return 100;
        if (avgLux <= 50f)  return 85;
        if (avgLux <= 100f) return 65;
        return 40;
    }

    // ---- Sleep duration (minutes → 0..100) ----
    // Optimal = 8h (480 min). ~1 point penalty per 6 min away.
    // Clamp <=3h or >=12h to 0.
    public static int sleepDurationScore(int minutes) {
        if (minutes <= 180) return 0;    // ≤3h
        if (minutes >= 720) return 0;    // ≥12h
        int optimal = 480;               // 8h
        int diff = Math.abs(minutes - optimal);
        int score = 100 - (int) Math.round(diff / 6.0);
        return clamp0to100(score);
    }

    // ---- Combined sleep score (duration + darkness) ----
    // Weighted: 70% duration, 30% darkness.
    public static int sleepCombined(int minutes, float avgLux) {
        int dur  = sleepDurationScore(minutes);
        int dark = sleepLux(avgLux);
        int combined = (int) Math.round(0.70 * dur + 0.30 * dark);
        return clamp0to100(combined);
    }

    // (Optional) Stricter variant where a poor sub-score drags more:
    // public static int sleepCombinedStrict(int minutes, float avgLux) {
    //     double dur  = sleepDurationScore(minutes) / 100.0;
    //     double dark = sleepLux(avgLux) / 100.0;
    //     double gm = Math.pow(dur, 0.70) * Math.pow(dark, 0.30); // geometric mean
    //     return clamp0to100((int) Math.round(100 * gm));
    // }

    // ---- Total (use weights above) ----
    public static int total(int stepsScore, int sleepScore, int noiseScore, int walkScore) {
        return Math.round(
                stepsScore * W_STEPS +
                        sleepScore * W_SLEEP +
                        noiseScore * W_NOISE +
                        walkScore  * W_WALK
        );
    }

    // ---- Grade (your current thresholds) ----
    // A: ≥90, B: ≥75, C: ≥60, D: ≥45, else F
    public static String grade(int s) {
        if (s >= 90) return "A";
        if (s >= 75) return "B";
        if (s >= 60) return "C";
        if (s >= 40) return "D";
        if (s >= 20) return "E";
        return "F";
    }


    // (Optional) Classic 10-point scale:
    // public static String gradeClassic(int s) {
    //     if (s >= 90) return "A";
    //     if (s >= 80) return "B";
    //     if (s >= 70) return "C";
    //     if (s >= 60) return "D";
    //     return "F";
    // }
}
