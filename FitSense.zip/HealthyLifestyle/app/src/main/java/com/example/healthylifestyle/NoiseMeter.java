package com.example.healthylifestyle;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

public class NoiseMeter {
    private AudioRecord record;
    private boolean running = false;
    private double avgDb = 0;

    public void start() {
        int rate = 44100;
        int buf = AudioRecord.getMinBufferSize(rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        record = new AudioRecord(MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf);
        record.startRecording();
        running = true;

        new Thread(() -> {
            short[] buffer = new short[buf];
            double sumDb = 0; int n=0;
            while (running){
                int read = record.read(buffer, 0, buffer.length);
                if (read > 0){
                    double sum = 0;
                    for (int i=0;i<read;i++) sum += buffer[i]*buffer[i];
                    double rms = Math.sqrt(sum / read);
                    double db = 20.0 * Math.log10(rms/32767.0 + 1e-9);
                    sumDb += (db + 90); // shift to human-friendly
                    n++;
                }
            }
            avgDb = n==0 ? 0 : sumDb/n;
        }).start();
    }

    public void stop(){
        running = false;
        if (record != null){
            try { record.stop(); record.release(); } catch (Exception ignored){}
        }
    }

    public float getAvgDb(){ return (float) avgDb; }
}
