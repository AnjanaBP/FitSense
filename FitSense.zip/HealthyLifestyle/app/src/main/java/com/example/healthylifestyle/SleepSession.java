package com.example.healthylifestyle;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "sleep_sessions")
public class SleepSession {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public long startTime;   // epoch millis
    public Long endTime;     // null until stopped

    public SleepSession(long startTime, Long endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
    }
}
