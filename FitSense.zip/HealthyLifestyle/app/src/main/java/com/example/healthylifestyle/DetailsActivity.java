package com.example.healthylifestyle;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class DetailsActivity extends AppCompatActivity {

    private static final float DEFAULT_NOISE_DB_OFFSET = 94f;

    private int displayNoiseDb(float dbfs) {
        int spl = Math.round(dbfs + DEFAULT_NOISE_DB_OFFSET);
        if (spl < 25)  spl = 25;
        if (spl > 110) spl = 110;
        return spl;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        // ---- Card layout views ----
        TextView tvGrade = findViewById(R.id.tvGrade);
        TextView tvScore = findViewById(R.id.tvScore);
        TextView tvSteps = findViewById(R.id.tvSteps);
        TextView tvLight = findViewById(R.id.tvLight);
        TextView tvNoise = findViewById(R.id.tvNoise);
        TextView tvWalk  = findViewById(R.id.tvWalk);
        TextView tvSleep = findViewById(R.id.tvSleep);

        // ---- Read extras from MainActivity (preferred) ----
        Intent i = getIntent();
        boolean hasExtras = i != null && i.hasExtra(MainActivity.EXTRA_STEPS);

        int   steps    = hasExtras ? i.getIntExtra(MainActivity.EXTRA_STEPS, 0) : 0;
        float lux      = hasExtras ? i.getFloatExtra(MainActivity.EXTRA_LUX, 0f)  : 0f;
        float dbfs     = hasExtras ? i.getFloatExtra(MainActivity.EXTRA_DB, 0f)   : 0f;
        float km       = hasExtras ? i.getFloatExtra(MainActivity.EXTRA_KM, 0f)   : 0f;
        int   sleepMin = hasExtras ? i.getIntExtra(MainActivity.EXTRA_SLEEP_MIN, 0) : 0;
        int   score    = hasExtras ? i.getIntExtra(MainActivity.EXTRA_SCORE, 0)   : 0;
        String grade   = hasExtras ? i.getStringExtra(MainActivity.EXTRA_GRADE)   : null;

        // ---- Lightweight recompute if nothing passed ----
        if (!hasExtras) {
            StepTracker stepTracker = new StepTracker(this);
            WalkTracker walkTracker = new WalkTracker(this);
            steps = stepTracker.getTodaySteps();
            km    = walkTracker.getKm();
        }

        // ---- Final fallback: last saved log ----
        if (!hasExtras && steps == 0 && lux == 0f && km == 0f) {
            AppDatabase db = AppDatabase.getInstance(this);
            LogEntry last = db.logDao().getLast();
            if (last != null) {
                steps = last.steps;
                lux   = last.lux;
                dbfs  = last.dbfs;   // ensure LogEntry has 'dbfs'
                km    = last.km;
                score = last.score;
                grade = last.grade;
            }
        }

        int spl = displayNoiseDb(dbfs);
        if (grade == null) grade = "--";

        // ---- Bind to UI ----
        tvGrade.setText(grade);
        tvScore.setText(String.valueOf(score));
        tvSteps.setText(String.valueOf(steps));
        tvLight.setText(String.format(Locale.getDefault(), "%.0f lux", lux));
        tvNoise.setText(String.format(Locale.getDefault(), "%d dB", spl));
        tvWalk.setText(String.format(Locale.getDefault(), "%.2f km", km));
        tvSleep.setText(String.format(Locale.getDefault(), "%dh %02dm", (sleepMin / 60), (sleepMin % 60)));
    }
}
