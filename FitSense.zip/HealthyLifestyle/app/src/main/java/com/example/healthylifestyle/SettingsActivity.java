package com.example.healthylifestyle;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private EditText etStepGoal, etWalkGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        etStepGoal = findViewById(R.id.etStepGoal);
        // IMPORTANT: match the ID in activity_settings.xml
        etWalkGoal = findViewById(R.id.etWalkGoalKm);
        Button btnSave = findViewById(R.id.btnSave);

        // Pre-fill from extras (with sensible defaults)
        int stepGoal = getIntent().getIntExtra("stepGoal", 8000);
        float walkGoalKm = getIntent().getFloatExtra("walkGoalKm", 3.0f);

        etStepGoal.setText(String.valueOf(stepGoal));
        etWalkGoal.setText(String.valueOf(walkGoalKm));

        btnSave.setOnClickListener(v -> {
            int newSteps = safeInt(etStepGoal.getText().toString(), stepGoal);
            float newWalk = safeFloat(etWalkGoal.getText().toString(), walkGoalKm);

            Intent out = new Intent();
            out.putExtra("stepGoal", newSteps);
            out.putExtra("walkGoalKm", newWalk);
            setResult(RESULT_OK, out);
            finish();
        });
    }

    private int safeInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); }
        catch (Exception e) { return def; }
    }

    private float safeFloat(String s, float def) {
        try { return Float.parseFloat(s.trim()); }
        catch (Exception e) { return def; }
    }
}
