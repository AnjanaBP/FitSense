package com.example.healthylifestyle;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class HistoryActivity extends AppCompatActivity {
    private LogDao logDao;
    private SleepDao sleepDao;
    private LogAdapter adapter;
    private TextView tvSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        setTitle("History");

        logDao = AppDatabase.getInstance(this).logDao();
        sleepDao = AppDatabase.getInstance(this).sleepDao();

        tvSummary = findViewById(R.id.tvSummary);
        RecyclerView rv = findViewById(R.id.recyclerHistory);
        rv.setLayoutManager(new LinearLayoutManager(this));

        // 1) Create adapter FIRST
        adapter = new LogAdapter(logDao.getAllDesc(), entry -> {
            logDao.deleteById(entry.id);
            loadAll();
        });

        // 2) Build sleep-duration-per-day map (works with primitive long fields)
        List<SleepSession> sessions = sleepDao.getAllCompleted();
        Map<String, Long> sleepMsByDay = new HashMap<>();
        if (sessions != null) {
            for (SleepSession s : sessions) {
                if (s == null) continue;
                long st = s.startTime;    // primitive long
                long en = s.endTime;      // primitive long
                if (st <= 0L || en <= 0L || en <= st) continue;
                long dur = en - st;

                String key = dayKey(en);  // assign to the day the session ended
                Long prev = sleepMsByDay.get(key);
                sleepMsByDay.put(key, (prev == null ? 0L : prev) + dur);
            }
        }

        // 3) Hand the map to the adapter AFTER it's created
        adapter.setSleepDurationsMap(sleepMsByDay);

        // 4) Attach adapter
        rv.setAdapter(adapter);

        Button btnAll = findViewById(R.id.btnAll);
        Button btnLast7 = findViewById(R.id.btnLast7);
        btnAll.setOnClickListener(v -> loadAll());
        btnLast7.setOnClickListener(v -> loadLast7());

        loadAll();
    }

    private static String dayKey(long epochMs) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(epochMs);
    }

    private void loadAll() {
        List<LogEntry> logs = logDao.getAllDesc();
        if (adapter != null) adapter.update(logs);
        updateSummary(logs);
    }

    private void loadLast7() {
        long sevenDays = 7L * 24 * 60 * 60 * 1000;
        long from = System.currentTimeMillis() - sevenDays;
        List<LogEntry> logs = logDao.getSince(from);
        if (adapter != null) adapter.update(logs);
        updateSummary(logs);
    }

    private void updateSummary(List<LogEntry> logs) {
        if (logs == null || logs.isEmpty()) {
            tvSummary.setText("Summary: (no data)");
            return;
        }
        int sum = 0;
        for (LogEntry e : logs) {
            // Use the actual numeric field in your entity.
            // Your inserts pass "total" variable to constructor,
            // but the entity field is typically named "score".
            sum += e.score;   // change to e.total if that's your field name
        }
        int avgScore = Math.round(sum / (float) logs.size());
        tvSummary.setText("Summary: Avg score " + avgScore);
    }
}
