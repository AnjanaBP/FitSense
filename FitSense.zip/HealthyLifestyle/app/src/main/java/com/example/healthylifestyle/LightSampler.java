package com.example.healthylifestyle;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class LightSampler {
    private final SensorManager sm;
    private final Sensor light;
    private float sum = 0f; private int count = 0;

    public LightSampler(Context ctx){
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        light = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
    }

    private final SensorEventListener listener = new SensorEventListener() {
        @Override public void onSensorChanged(SensorEvent e) { sum += e.values[0]; count++; }
        @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };

    public void start(){ if (light != null){ sum=0; count=0; sm.registerListener(listener, light, SensorManager.SENSOR_DELAY_NORMAL);} }
    public void stop(){ sm.unregisterListener(listener); }
    public float getAverageLux(){ return count == 0 ? 0f : sum / count; }
    public boolean isAvailable(){ return light != null; }
}
