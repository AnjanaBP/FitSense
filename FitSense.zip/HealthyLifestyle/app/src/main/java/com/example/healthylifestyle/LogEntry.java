package com.example.healthylifestyle;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "daily_logs")
public class LogEntry {

    @PrimaryKey(autoGenerate = true)
    public long id;

    /** When this row was saved (epoch millis). */
    public long timestamp;

    public int steps;
    public float lux;

    /** Noise level as raw dBFS (usually negative). */
    @ColumnInfo(name = "dbfs")
    public float dbfs;

    public float km;
    public int score;
    public String grade;

    public LogEntry(long timestamp,
                    int steps,
                    float lux,
                    float dbfs,
                    float km,
                    int score,
                    String grade) {
        this.timestamp = timestamp;
        this.steps = steps;
        this.lux = lux;
        this.dbfs = dbfs;
        this.km = km;
        this.score = score;
        this.grade = grade;
    }
}
