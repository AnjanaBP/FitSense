plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.healthylifestyle"
    compileSdk = 34   // OK to compile with 34 while targetSdk stays 32

    defaultConfig {
        applicationId = "com.example.healthylifestyle"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // Java 17 (Android Studio 2024.3 default)
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Optional but handy
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Jetpack
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.8.4")
    implementation("androidx.lifecycle:lifecycle-livedata:2.8.4")

    // Room (Java)
    implementation("androidx.room:room-runtime:2.6.1")
    annotationProcessor("androidx.room:room-compiler:2.6.1")

    // Location (Fused)
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation ("com.google.android.material:material:1.12.0")


    // Charts (optional, needs JitPack if you add it later)
    // implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")
}
